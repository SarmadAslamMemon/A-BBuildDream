package com.example.abbuilddream.ui.activity.fragments;

import static com.example.abbuilddream.api.RetrofitClient.baseUrl;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.abbuilddream.R;
import com.example.abbuilddream.adaptor.DashBoardAdapter;
import com.example.abbuilddream.adaptor.Slider_Adapter;
import com.example.abbuilddream.api.RetroInterface;
import com.example.abbuilddream.api.RetrofitClient;
import com.example.abbuilddream.model.Product;
import com.example.abbuilddream.ui.activity.MainDashBoard;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class dashboard_fragment extends Fragment {

    RecyclerView recyclerView;
    ViewPager viewPager_dashboard;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dashboard_fragment, container, false);

        // Initialize the ViewPager
        viewPager_dashboard = view.findViewById(R.id.slider_dashboard);

        // Create a list of images
        ArrayList<Integer> images = new ArrayList<>();

        images.add(R.drawable.home);
        images.add(R.drawable.notification_ic);

        // Set up the adapter with context
        Slider_Adapter myadapter = new Slider_Adapter(getContext(), images);
        viewPager_dashboard.setAdapter(myadapter);

        findViewByIds(view);
        fetchProducts();
        return view;
    }



    private void findViewByIds(View view)
    {
        recyclerView=view.findViewById(R.id.productRecyclerView);
    }


    private void fetchProducts() {
        RetroInterface apiService = RetrofitClient.getClient(baseUrl).create(RetroInterface.class);
        Call<List<Product>> call = apiService.getProducts();
        call.enqueue(new Callback<List<Product>>() {
            @Override
            public void onResponse(@NonNull Call<List<Product>> call, @NonNull Response<List<Product>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<Product> products = response.body();

                    DashBoardAdapter dashBoardAdapter=new DashBoardAdapter(getContext(),products);
                    recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                    recyclerView.setAdapter(dashBoardAdapter);
                    Log.d("jarvis", "Products received: ");
                } else {
                    Log.e("jarvis", "Request failed with code: " + response.code());
                }
            }

            @Override
            public void onFailure(@NonNull Call<List<Product>> call, @NonNull Throwable t) {
                // Handle failure
                Log.e("jarvis", "Request failed", t);
            }
        });
    }
}