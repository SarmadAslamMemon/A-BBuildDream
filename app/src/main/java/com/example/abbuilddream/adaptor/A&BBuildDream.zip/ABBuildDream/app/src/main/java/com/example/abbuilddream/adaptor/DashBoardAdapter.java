package com.example.abbuilddream.adaptor;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide; // For loading images
import com.example.abbuilddream.R;
import com.example.abbuilddream.model.Product;

import java.util.List;

public class DashBoardAdapter extends RecyclerView.Adapter<DashBoardAdapter.DashBoardViewHolder> {

    private final Context context;
    private final List<Product> productList;

    // Constructor to initialize context and product list
    public DashBoardAdapter(Context context, List<Product> productList) {
        this.context = context;
        this.productList = productList;
    }

    @NonNull
    @Override
    public DashBoardViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the item layout
        View view = LayoutInflater.from(context).inflate(R.layout.product_item_layout, parent, false);
        return new DashBoardViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DashBoardViewHolder holder, int position) {
        // Bind data to each item view
        Product product = productList.get(position);
        holder.productCardNameTextView.setText(product.getName());
        holder.productCardPriceTextView.setText("$ " + product.getPrice());
        Glide.with(context)
                .load("https://yourserver.com/images/" + product.getImage())
                .into(holder.productCardImageView);
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    // ViewHolder class to hold references to each item's views
    public static class DashBoardViewHolder extends RecyclerView.ViewHolder {

        TextView productCardNameTextView, productCardPriceTextView;
        ImageView productCardImageView;

        public DashBoardViewHolder(@NonNull View itemView) {
            super(itemView);
            // Initialize views
            productCardImageView = itemView.findViewById(R.id.productCardImageView);
            productCardNameTextView = itemView.findViewById(R.id.productCardNameTextView);
            productCardPriceTextView = itemView.findViewById(R.id.productCardPriceTextView);
        }
    }
}
